## showcases: https://www.figma.com/community/file/1252610051102275471

## hero & footer: https://www.figma.com/community/file/1202426685198179521

